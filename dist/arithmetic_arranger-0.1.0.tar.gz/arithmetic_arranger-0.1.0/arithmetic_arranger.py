def arithmetic_arranger(problems, bool):

    fail_message=""

    return problems, fail_message